export function reviewEndpoint(location, configured) {
  if (configured) {
    try {
      const url = new URL(configured);
      const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
      if (url.username || url.password || url.pathname !== '/' || url.search || url.hash) return null;
      return url.protocol === 'https:' || (local && url.protocol === 'http:') ? url.origin : null;
    } catch { return null; }
  }
  return ['localhost', '127.0.0.1'].includes(location.hostname) ? 'http://127.0.0.1:47831' : null;
}

export async function previewImage(source) {
  const bitmap = source instanceof Blob ? await createImageBitmap(source) : source;
  try {
    if (!bitmap.width || !bitmap.height) throw new Error('No canvas is ready to share.');
    const scale = Math.min(1, 1440 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Preview capture is unavailable.');
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.86);
  } finally { if (bitmap !== source) bitmap.close(); }
}

export function openReview({ endpoint, product, title, capture, isCurrent }) {
  const origin = reviewEndpoint({ hostname: '' }, endpoint);
  if (!origin) throw new Error('A secure review endpoint is required.');
  const channel = crypto.randomUUID();
  const popup = window.open(`${origin}/#bridge=${channel}&parent=${encodeURIComponent(location.origin)}`, '_blank');
  if (!popup) throw new Error('Allow the review window to open, then try again.');
  let busy = false;
  let disposed = false;
  const send = (message) => popup.postMessage({ ...message, channel }, origin);
  const receive = async (event) => {
    if (disposed || event.origin !== origin || event.source !== popup || event.data?.channel !== channel) return;
    if (event.data.type === 'review:context') {
      send({ type: 'review:context', product, title });
    } else if (event.data.type === 'review:capture' && !busy) {
      if (!isCurrent()) return send({ type: 'review:error', message: 'The source document changed. Start a new review for this document.' });
      busy = true;
      try {
        const image = await capture();
        // Captures may be asynchronous; never publish a different document after a tab switch.
        if (!disposed && isCurrent()) send({ type: 'review:frame', image });
        else if (!disposed) send({ type: 'review:error', message: 'Source changed during capture. No frame was shared.' });
      } catch (error) { if (!disposed) send({ type: 'review:error', message: error instanceof Error ? error.message : 'Capture failed.' }); }
      finally { busy = false; }
    }
  };
  window.addEventListener('message', receive);
  const dispose = () => {
    disposed = true;
    window.removeEventListener('message', receive);
    window.clearInterval(timer);
    if (!popup.closed) send({ type: 'review:error', message: 'The source editor disconnected.' });
  };
  const timer = window.setInterval(() => { if (popup.closed) dispose(); }, 2000);
  return dispose;
}

export const collaborationEndpoint = 'https://momentium-collaboration.armonon.chatgpt.site';

export function openCollaboration({ endpoint = ['localhost', '127.0.0.1'].includes(location.hostname) ? 'http://127.0.0.1:47834' : collaborationEndpoint, product, title, capture, isCurrent, read, apply }) {
  const origin = reviewEndpoint({ hostname: '' }, endpoint);
  if (!origin) throw new Error('A secure collaboration endpoint is required.');
  const initial = read();
  if (!initial.length || initial.length > 300) throw new Error('Share a document with 1 to 300 supported properties.');
  const shape = JSON.stringify(initial.map(({ id, type, min, max }) => ({ id, type, min, max })));
  const fields = () => {
    if (!isCurrent()) throw new Error('The source document changed. Start a new collaboration session.');
    const current = read();
    if (JSON.stringify(current.map(({ id, type, min, max }) => ({ id, type, min, max }))) !== shape) throw new Error('Document structure or locks changed. Start a new collaboration session.');
    return current;
  };
  const channel = crypto.randomUUID();
  const popup = window.open(`${origin}/#bridge=${channel}&parent=${encodeURIComponent(location.origin)}`, '_blank');
  if (!popup) throw new Error('Allow the collaboration window to open, then try again.');
  let disposed = false, busy = false;
  const send = message => popup.postMessage({ ...message, channel }, origin);
  const receive = async event => {
    if (disposed || event.origin !== origin || event.source !== popup || event.data?.channel !== channel) return;
    const msg = event.data;
    if (!['collab:context', 'collab:read', 'collab:apply', 'collab:capture'].includes(msg.type)) return;
    try {
      const current = fields();
      if (msg.type === 'collab:context') send({ type: msg.type, title, product, fields: current });
      if (msg.type === 'collab:read') send({ type: msg.type, fields: current, request: msg.request });
      if (msg.type === 'collab:apply') {
        if (!msg.values || typeof msg.values !== 'object' || !msg.baseline || typeof msg.baseline !== 'object') throw new Error('Invalid shared edit.');
        const changes = {}, conflicts = [];
        for (const [id, value] of Object.entries(msg.values)) {
          const field = current.find(f => f.id === id);
          if (!field || !(field.type === 'number' ? typeof value === 'number' && Number.isFinite(value) && value >= (field.min ?? -1e6) && value <= (field.max ?? 1e6) : field.type === 'boolean' ? typeof value === 'boolean' : typeof value === 'string' && value.length <= 240)) throw new Error('Unsupported shared edit.');
          // Preserve unsent local changes instead of silently overwriting them.
          if (field.value !== msg.baseline[id] && field.value !== value) conflicts.push(id);
          else if (field.value !== value) changes[id] = value;
        }
        if (Object.keys(changes).length) await apply(changes);
        send({ type: 'collab:applied', request: msg.request, fields: fields(), conflicts });
      }
      if (msg.type === 'collab:capture' && !busy) {
        busy = true;
        try { const image = await capture(); fields(); if (!disposed) send({ type: 'collab:frame', image }); }
        finally { busy = false; }
      }
    } catch (error) { if (!disposed) send({ type: 'collab:error', message: error instanceof Error ? error.message : 'Shared edit failed.' }); }
  };
  window.addEventListener('message', receive);
  const dispose = () => { disposed = true; window.removeEventListener('message', receive); clearInterval(timer); if (!popup.closed) send({ type: 'collab:error', message: 'The source editor disconnected.' }); };
  const timer = setInterval(() => { if (popup.closed) dispose(); }, 2000);
  return dispose;
}
