export function reviewEndpoint(location: Pick<Location, 'hostname'>, configured?: string): string | null;
export function previewImage(source: HTMLCanvasElement | Blob): Promise<string>;
export function openReview(options: {
  endpoint: string;
  product: string;
  title: string;
  capture: () => Promise<string>;
  isCurrent: () => boolean;
}): () => void;
export type SharedField = { id: string; group: string; label: string; type: 'number' | 'text' | 'boolean'; min?: number; max?: number; value: string | number | boolean };
export const collaborationEndpoint: string;
export function openCollaboration(options: {
  endpoint?: string;
  product: string;
  title: string;
  capture: () => Promise<string>;
  isCurrent: () => boolean;
  read: () => SharedField[];
  apply: (values: Record<string, string | number | boolean>) => void | Promise<void>;
}): () => void;
