export function reviewEndpoint(location: Pick<Location, 'hostname'>, configured?: string): string | null;
export function previewImage(source: HTMLCanvasElement | Blob): Promise<string>;
export function openReview(options: {
  endpoint: string;
  product: string;
  title: string;
  capture: () => Promise<string>;
  isCurrent: () => boolean;
}): () => void;
